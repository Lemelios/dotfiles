import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

// EXEMPLE : adapte-le à ton WifiWdg actuel (garde ton `value`, ton `icon`, etc.).
// DataSec doit avoir le signal `clicked` (voir les modifs de DataSec.qml).
DataSec {
    id: root
    icon: "󰖩"
    // value: ...  <- ta logique actuelle d'affichage de la connexion courante

    onClicked: wifiWin.toggle()

    // Modèle des réseaux, rempli par le scan ci-dessous.
    // Placé ici (hors de `content`) pour survivre à la fermeture de la popup.
    ListModel { id: networks }

    // Scan : -t = sortie compacte séparée par ":".
    // SSID en DERNIER car il peut lui-même contenir des ":".
    Process {
        id: scan
        command: ["nmcli", "-t", "--escape", "no", "-f", "IN-USE,SIGNAL,SECURITY,SSID", "dev", "wifi", "list"]
        stdout: StdioCollector {
            onStreamFinished: {
                const rows = text.trim().split("\n").filter(l => l !== "").map(l => {
                    const p = l.split(":")
                    return {
                        active: p[0] === "*",
                        strength: parseInt(p[1]),
                        secured: p[2] !== "" && p[2] !== "--",   // nmcli met "--" pour un réseau ouvert
                        ssid: p.slice(3).join(":")              // recolle un SSID contenant des ":"
                    }
                }).filter(r => r.ssid !== "")

                // Réseau connecté d'abord, puis par puissance décroissante
                rows.sort((a, b) => (b.active - a.active) || (b.strength - a.strength))

                // Un même SSID peut apparaître via plusieurs bornes : on garde la première
                const seen = {}
                networks.clear()
                rows.forEach(r => {
                    if (!seen[r.ssid]) { seen[r.ssid] = true; networks.append(r) }
                })
            }
        }
    }

    // Connexion (profils déjà connus ou réseaux ouverts ; pas de saisie de mot de passe ici).
    // Le SSID est passé comme argument séparé, sans shell : pas d'injection possible.
    Process {
        id: connect
        onExited: scan.running = true   // rafraîchit la liste après la tentative
    }

    DataWindow {
        id: wifiWin
        target: root
        title: "Réseaux Wi-Fi"
        minWidth: 280

        // Rescan à chaque ouverture
        onVisibleChanged: if (visible) scan.running = true

        content: ColumnLayout {
            spacing: 4

            Repeater {
                model: networks

                delegate: Rectangle {
                    id: row
                    required property string ssid
                    required property int strength
                    required property bool secured
                    required property bool active

                    Layout.fillWidth: true
                    implicitHeight: 30
                    radius: 8
                    color: row.active ? Colors.eludedFGreen : (hover.containsMouse ? Colors.eludedDGreen : "transparent")

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Text {
                            Layout.fillWidth: true
                            text: row.ssid
                            elide: Text.ElideRight
                            color: Colors.basePurple
                            font { family: "Terminess Nerd Font Proto"; pixelSize: 14; bold: row.active }
                        }
                        Text {
                            visible: row.secured
                            text: "\uf023"   // cadenas (Nerd Font)
                            color: Colors.darkPurple
                            font { family: "Terminess Nerd Font Proto"; pixelSize: 12 }
                        }
                        Text {
                            text: row.strength + "%"
                            color: Colors.darkGreen
                            font { family: "Terminess Nerd Font Proto"; pixelSize: 12 }
                        }
                    }

                    MouseArea {
                        id: hover
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: {
                            if (row.active) return
                            connect.command = ["nmcli", "dev", "wifi", "connect", row.ssid]
                            connect.running = true
                        }
                    }
                }
            }

            Text {
                visible: networks.count === 0
                text: "Recherche en cours…"
                color: Colors.darkGreen
                font { family: "Terminess Nerd Font Proto"; pixelSize: 13 }
            }
        }
    }
}
